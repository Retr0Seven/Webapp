package dev.danvickmiller.flutterformbuilder.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
